# A Mano Cuba — proyecto Android nativo

Proyecto fuente Android-only en Kotlin + Jetpack Compose. No utiliza HTML ni WebView.

## Incluye
- Catálogo local de alimentos, categorías y búsqueda.
- Mercados configurables y precios reportados por mercado, con fecha.
- Comparación de los reportes guardados para dos mercados.
- Lista de compra, horario semanal editable y tareas de estudio, guardados localmente.
- Temporizador de concentración de 15 minutos mientras la aplicación permanece abierta.
- Vista sencilla con texto ampliado.
- Sin permisos de internet ni servicios externos: las funciones disponibles operan offline.

## Límites de esta versión
Los mercados, precios, tareas y listas se guardan en el almacenamiento privado de esta instalación. **No se sincronizan entre teléfonos** y no existe un servidor de reportes. Los precios deben añadirse manualmente y no son oficiales. El temporizador no genera alarmas cuando la app está cerrada.

## Compilación
Preparado para Android Gradle Plugin 8.7.3, Kotlin 2.0.21, JDK 17 y Android SDK Platform 35; minSdk 23. Abre esta carpeta en Android Studio, sincroniza Gradle y compila el APK de depuración desde Build > Build APK(s).

Este paquete contiene **código fuente, no una APK**. La compilación y las pruebas en emulador o teléfono siguen pendientes; no se deben considerar verificadas.

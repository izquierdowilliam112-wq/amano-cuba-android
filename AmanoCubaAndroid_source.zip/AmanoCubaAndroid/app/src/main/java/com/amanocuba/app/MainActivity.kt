package com.amanocuba.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF176B54)
private val GreenPale = Color(0xFFE6F3ED)
private val Ink = Color(0xFF18352F)
private val Muted = Color(0xFF657770)
private val Paper = Color(0xFFF6F8F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = LocalStore(applicationContext)
        setContent { AmanoTheme { AmanoApp(store) } }
    }
}

private data class Food(val id: String, val name: String, val category: String, val emoji: String, val unit: String)
private data class Market(val id: String, val name: String, val area: String)
private data class PriceReport(val id: String, val foodId: String, val marketId: String, val price: Double, val date: String)
private data class StudyTask(val id: String, val text: String, val done: Boolean)
private data class ClassSession(val id: String, val day: String, val time: String, val subject: String)
private data class AppState(
    val markets: List<Market> = emptyList(),
    val reports: List<PriceReport> = emptyList(),
    val shopping: List<String> = emptyList(),
    val tasks: List<StudyTask> = emptyList(),
    val selectedMarketId: String = "",
    val schedule: List<ClassSession> = emptyList()
)

private val foods = listOf(
    Food("arroz", "Arroz", "Granos", "🍚", "libra"),
    Food("frijoles", "Frijoles", "Granos", "🫘", "libra"),
    Food("harina", "Harina", "Granos", "🌾", "libra"),
    Food("pan", "Pan", "Panadería", "🥖", "unidad"),
    Food("leche", "Leche", "Lácteos", "🥛", "litro"),
    Food("huevo", "Huevo", "Lácteos", "🥚", "unidad"),
    Food("queso", "Queso", "Lácteos", "🧀", "libra"),
    Food("pollo", "Pollo", "Carnes", "🍗", "libra"),
    Food("cerdo", "Carne de cerdo", "Carnes", "🥩", "libra"),
    Food("picadillo", "Picadillo", "Carnes", "🍖", "libra"),
    Food("tomate", "Tomate", "Frutas y vegetales", "🍅", "libra"),
    Food("cebolla", "Cebolla", "Frutas y vegetales", "🧅", "libra"),
    Food("ajo", "Ajo", "Frutas y vegetales", "🧄", "cabeza"),
    Food("papa", "Papa", "Frutas y vegetales", "🥔", "libra"),
    Food("platano", "Plátano", "Frutas y vegetales", "🍌", "unidad"),
    Food("yuca", "Yuca", "Frutas y vegetales", "🥔", "libra"),
    Food("aceite", "Aceite", "Otros", "🫗", "litro"),
    Food("azucar", "Azúcar", "Otros", "🧂", "libra"),
    Food("cafe", "Café", "Otros", "☕", "paquete"),
    Food("agua", "Agua", "Otros", "💧", "litro")
)

private class LocalStore(context: android.content.Context) {
    private val prefs = context.getSharedPreferences("amano_cuba", android.content.Context.MODE_PRIVATE)
    private val _state = mutableStateOf(readState())
    val state: State<AppState> get() = _state

    fun update(transform: (AppState) -> AppState) {
        val next = transform(_state.value)
        _state.value = next
        writeState(next)
    }

    private fun readState(): AppState = try {
        val root = JSONObject(prefs.getString("data", "{}") ?: "{}")
        val markets = root.optJSONArray("markets").toModels { o -> Market(o.optString("id"), o.optString("name"), o.optString("area")) }
        val reports = root.optJSONArray("reports").toModels { o -> PriceReport(o.optString("id"), o.optString("foodId"), o.optString("marketId"), o.optDouble("price"), o.optString("date")) }
        val shopping = root.optJSONArray("shopping").toStrings()
        val tasks = root.optJSONArray("tasks").toModels { o -> StudyTask(o.optString("id"), o.optString("text"), o.optBoolean("done")) }
        val schedule = root.optJSONArray("schedule").toModels { o -> ClassSession(o.optString("id"), o.optString("day"), o.optString("time"), o.optString("subject")) }
        AppState(markets = markets, reports = reports, shopping = shopping, tasks = tasks, selectedMarketId = root.optString("selectedMarketId"), schedule = schedule)
    } catch (_: Exception) { AppState() }

    private fun writeState(state: AppState) {
        val root = JSONObject()
        root.put("markets", JSONArray().apply { state.markets.forEach { put(JSONObject().put("id", it.id).put("name", it.name).put("area", it.area)) } })
        root.put("reports", JSONArray().apply { state.reports.forEach { put(JSONObject().put("id", it.id).put("foodId", it.foodId).put("marketId", it.marketId).put("price", it.price).put("date", it.date)) } })
        root.put("shopping", JSONArray().apply { state.shopping.forEach { put(it) } })
        root.put("tasks", JSONArray().apply { state.tasks.forEach { put(JSONObject().put("id", it.id).put("text", it.text).put("done", it.done)) } })
        root.put("schedule", JSONArray().apply { state.schedule.forEach { put(JSONObject().put("id", it.id).put("day", it.day).put("time", it.time).put("subject", it.subject)) } })
        root.put("selectedMarketId", state.selectedMarketId)
        prefs.edit().putString("data", root.toString()).apply()
    }
}

private fun JSONArray?.toStrings(): List<String> = if (this == null) emptyList() else (0 until length()).mapNotNull { optString(it).takeIf(String::isNotBlank) }
private inline fun <T> JSONArray?.toModels(mapper: (JSONObject) -> T): List<T> = if (this == null) emptyList() else (0 until length()).mapNotNull { index -> optJSONObject(index)?.let(mapper) }

private enum class Page(val title: String, val icon: String) {
    HOME("Inicio", "⌂"), CATALOG("Catálogo", "🥬"), COMPARE("Comparar", "⇄"), YOUTH("Jóvenes", "📚"), EASY("Fácil", "☼")
}

@Composable
private fun AmanoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, onPrimary = Color.White, secondary = Color(0xFFD8F27A), background = Paper, surface = Color.White, onSurface = Ink)) { content() }
}

@Composable
private fun AmanoApp(store: LocalStore) {
    val state by store.state
    val context = LocalContext.current
    var page by remember { mutableStateOf(Page.HOME) }
    var easyText by remember { mutableStateOf(false) }
    var showMarketDialog by remember { mutableStateOf(false) }
    var chooseMarket by remember { mutableStateOf(false) }
    var reportFood by remember { mutableStateOf<Food?>(null) }
    var listOpen by remember { mutableStateOf(false) }
    val scale = if (easyText || page == Page.EASY) 1.18f else 1f

    Scaffold(
        containerColor = Paper,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                Page.entries.forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = { Text(item.icon, fontSize = 19.sp) },
                        label = { Text(item.title, fontSize = (10 * scale).sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            Header(easyText) { easyText = !easyText }
            when {
                listOpen -> ShoppingPage(state, store) { listOpen = false }
                page == Page.HOME -> HomePage(state, store, scale,
                    onPickMarket = { chooseMarket = true }, onAddMarket = { showMarketDialog = true },
                    onGo = { page = it }, onOpenList = { listOpen = true })
                page == Page.CATALOG -> CatalogPage(state, store, scale,
                    onAddMarket = { showMarketDialog = true }, onReport = { food ->
                        if (state.markets.any { it.id == state.selectedMarketId }) reportFood = food
                        else Toast.makeText(context, "Añade o selecciona un mercado primero", Toast.LENGTH_SHORT).show()
                    }, onOpenList = { listOpen = true })
                page == Page.COMPARE -> ComparePage(state, scale)
                page == Page.YOUTH -> YouthPage(state, store, scale, onCatalog = { page = Page.CATALOG })
                else -> EasyPage(state, scale, onCatalog = { page = Page.CATALOG }, onList = { listOpen = true })
            }
        }
    }

    if (showMarketDialog) MarketDialog(onDismiss = { showMarketDialog = false }) { name, area ->
        val market = Market("m_${System.currentTimeMillis()}", name, area)
        store.update { it.copy(markets = it.markets + market, selectedMarketId = market.id) }
        showMarketDialog = false
        Toast.makeText(context, "Mercado guardado en este teléfono", Toast.LENGTH_SHORT).show()
    }
    if (chooseMarket) ChoiceDialog("Elige un mercado", state.markets.map { it.id to (it.name + if (it.area.isBlank()) "" else " · ${it.area}") }, onDismiss = { chooseMarket = false }) { id ->
        store.update { it.copy(selectedMarketId = id) }; chooseMarket = false
    }
    reportFood?.let { food ->
        val market = state.markets.find { it.id == state.selectedMarketId }
        if (market != null) PriceDialog(food, market, onDismiss = { reportFood = null }) { price, date ->
            val report = PriceReport("r_${System.currentTimeMillis()}", food.id, market.id, price, date)
            store.update { it.copy(reports = it.reports + report) }
            reportFood = null
            Toast.makeText(context, "Reporte guardado localmente", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
private fun Header(easyText: Boolean, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(color = Green, shape = RoundedCornerShape(14.dp), modifier = Modifier.size(40.dp)) { Box(contentAlignment = Alignment.Center) { Text("✳", color = Color.White, fontSize = 22.sp) } }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("A Mano", fontWeight = FontWeight.ExtraBold, color = Ink, fontSize = 18.sp)
            Text("CUBA · ANDROID", color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp, fontWeight = FontWeight.Bold)
        }
        TextButtonLike(if (easyText) "Aa Normal" else "Aa Fácil", onToggle)
    }
}

@Composable
private fun TextButtonLike(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, shape = RoundedCornerShape(14.dp)) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun HomePage(state: AppState, store: LocalStore, scale: Float, onPickMarket: () -> Unit, onAddMarket: () -> Unit, onGo: (Page) -> Unit, onOpenList: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Text("Hola 👋 · Tu ayuda diaria", color = Muted, fontSize = (13 * scale).sp, modifier = Modifier.padding(top = 4.dp))
        Card(shape = RoundedCornerShape(25.dp), colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Green), modifier = Modifier.fillMaxWidth().padding(top = 9.dp)) {
            Column(Modifier.padding(21.dp)) {
                Text("ORGANÍZATE A TU MANERA", color = Color(0xFFCBE9D8), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text("Lo útil, más cerca.", color = Color.White, fontSize = (30 * scale).sp, lineHeight = (35 * scale).sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 7.dp))
                Text("Precios por mercado, lista de compra y tareas en un solo lugar.", color = Color(0xFFE0EEE7), fontSize = (13 * scale).sp, modifier = Modifier.padding(top = 5.dp))
                Spacer(Modifier.height(15.dp))
                val market = state.markets.find { it.id == state.selectedMarketId }
                OutlinedButton(onClick = onPickMarket, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                    Text(if (market == null) "Elegir mercado" else "📍 ${market.name}", color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                TextButton(onClick = onAddMarket) { Text("＋ Añadir un mercado", color = Color(0xFFD8F27A), fontWeight = FontWeight.Bold) }
            }
        }
        SectionTitle("¿Qué necesitas hoy?", scale)
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
            QuickTile("🥕", "Alimentos", "Catálogo", scale, Modifier.weight(1f)) { onGo(Page.CATALOG) }
            QuickTile("📊", "Comparar", "Mercados", scale, Modifier.weight(1f)) { onGo(Page.COMPARE) }
            QuickTile("📚", "Mi semana", "Tareas", scale, Modifier.weight(1f)) { onGo(Page.YOUTH) }
        }
        Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Tu lista de compra", fontSize = (19 * scale).sp, fontWeight = FontWeight.Bold); Text("${state.shopping.size} productos", color = Muted, fontSize = 12.sp) }
            TextButton(onClick = onOpenList) { Text("Ver lista →") }
        }
        ShoppingRows(state, store, scale, compact = true)
        Text("Los precios son reportes guardados en este teléfono; confirma el dato y la fecha en el mercado.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 16.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickTile(emoji: String, title: String, subtitle: String, scale: Float, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Color(0xFFE6ECE8)), modifier = modifier) {
        Column(Modifier.padding(12.dp).fillMaxWidth()) {
            Text(emoji, fontSize = 22.sp)
            Text(title, fontSize = (12 * scale).sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
            Text(subtitle, fontSize = (10 * scale).sp, color = Muted, maxLines = 1)
        }
    }
}

@Composable
private fun SectionTitle(text: String, scale: Float) {
    Text(text, fontSize = (20 * scale).sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 11.dp))
}

@Composable
private fun CatalogPage(state: AppState, store: LocalStore, scale: Float, onAddMarket: () -> Unit, onReport: (Food) -> Unit, onOpenList: () -> Unit) {
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    var chooseMarket by remember { mutableStateOf(false) }
    val categories = listOf("Todos") + foods.map { it.category }.distinct()
    val market = state.markets.find { it.id == state.selectedMarketId }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Text("Catálogo de alimentos", fontSize = (26 * scale).sp, fontWeight = FontWeight.ExtraBold, color = Ink, modifier = Modifier.padding(top = 8.dp))
            Text("Consulta y registra precios para cada mercado.", color = Muted, fontSize = (13 * scale).sp)
            Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) {
                Column(Modifier.padding(14.dp)) {
                    OutlinedButton(onClick = { chooseMarket = true }, modifier = Modifier.fillMaxWidth()) { Text(market?.name ?: "Selecciona un mercado", maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    TextButton(onClick = onAddMarket) { Text("＋ Añadir mercado") }
                    Text("Los precios se reportan manualmente y se guardan en este teléfono.", fontSize = 11.sp, color = Muted)
                }
            }
            OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Buscar alimento") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 11.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                categories.forEach { cat -> if (cat == category) Button(onClick = { category = cat }) { Text(cat) } else OutlinedButton(onClick = { category = cat }) { Text(cat) } }
            }
            val matches = foods.filter { (category == "Todos" || it.category == category) && it.name.contains(search, ignoreCase = true) }
            matches.forEach { food -> FoodCard(food, state, scale, onReport) }
            if (matches.isEmpty()) EmptyMessage("No encontramos alimentos con esa búsqueda.")
        }
        Button(onClick = onOpenList, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) { Text("🧺 Mi lista (${state.shopping.size})") }
    }
    if (chooseMarket) ChoiceDialog("Elige un mercado", state.markets.map { it.id to (it.name + if (it.area.isBlank()) "" else " · ${it.area}") }, onDismiss = { chooseMarket = false }) { id ->
        store.update { it.copy(selectedMarketId = id) }; chooseMarket = false
    }
}

@Composable
private fun FoodCard(food: Food, state: AppState, scale: Float, onReport: (Food) -> Unit) {
    val report = state.reports.filter { it.foodId == food.id && it.marketId == state.selectedMarketId }.maxByOrNull { it.date }
    Card(shape = RoundedCornerShape(17.dp), border = BorderStroke(1.dp, Color(0xFFE6ECE8)), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(food.emoji, fontSize = 28.sp)
            Column(Modifier.weight(1f).padding(horizontal = 11.dp)) {
                Text(food.name, fontWeight = FontWeight.Bold, fontSize = (15 * scale).sp)
                Text("por ${food.unit} · ${food.category}", color = Muted, fontSize = (11 * scale).sp)
                if (report != null) {
                    Text("${formatCup(report.price)} · ${report.date}", color = Green, fontWeight = FontWeight.Bold, fontSize = (12 * scale).sp)
                    Text("Reporte local · verifica antes de comprar", color = Muted, fontSize = 10.sp)
                } else Text("Sin precio reportado", color = Color(0xFF865D28), fontSize = (11 * scale).sp, modifier = Modifier.padding(top = 3.dp))
            }
            Column(horizontalAlignment = Alignment.End) {
                TextButton(onClick = { onReport(food) }) { Text("＋ Precio") }
            }
        }
    }
}

@Composable
private fun ComparePage(state: AppState, scale: Float) {
    var selectedFood by remember { mutableStateOf(foods.first().id) }
    var choosing by remember { mutableStateOf("") }
    var marketA by remember { mutableStateOf("") }
    var marketB by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Text("Comparar mercados", fontSize = (26 * scale).sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp))
        Text("Compara reportes del mismo alimento.", color = Muted)
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
            Column(Modifier.padding(17.dp)) {
                Text("Alimento", fontWeight = FontWeight.Bold)
                ChoiceButton(foods.find { it.id == selectedFood }?.name ?: "Seleccionar", Modifier.fillMaxWidth()) { choosing = "food" }
                Text("Primer mercado", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                ChoiceButton(state.markets.find { it.id == marketA }?.name ?: "Seleccionar", Modifier.fillMaxWidth()) { choosing = "a" }
                Text("Segundo mercado", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                ChoiceButton(state.markets.find { it.id == marketB }?.name ?: "Seleccionar", Modifier.fillMaxWidth()) { choosing = "b" }
            }
        }
        if (marketA.isNotBlank() || marketB.isNotBlank()) {
            listOf(marketA, marketB).filter(String::isNotBlank).distinct().forEach { marketId ->
                val m = state.markets.find { it.id == marketId }
                val r = state.reports.filter { it.marketId == marketId && it.foodId == selectedFood }.maxByOrNull { it.date }
                Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(m?.name ?: "Mercado", fontWeight = FontWeight.Bold); Text(if (r == null) "Sin reporte para este alimento" else "Reporte ${r.date}", fontSize = 11.sp, color = Muted) }
                        Text(r?.let { formatCup(it.price) } ?: "—", fontWeight = FontWeight.ExtraBold, color = Green)
                    }
                }
            }
        } else EmptyMessage("Elige mercados para consultar los precios registrados.")
        Text("Los reportes no se comparten con otros teléfonos en esta versión.", fontSize = 11.sp, color = Muted, modifier = Modifier.padding(top = 14.dp))
    }
    if (choosing == "food") ChoiceDialog("Elige un alimento", foods.map { it.id to "${it.emoji} ${it.name}" }, { choosing = "" }) { selectedFood = it; choosing = "" }
    if (choosing == "a" || choosing == "b") ChoiceDialog("Elige un mercado", state.markets.map { it.id to (it.name + if (it.area.isBlank()) "" else " · ${it.area}") }, { choosing = "" }) { id -> if (choosing == "a") marketA = id else marketB = id; choosing = "" }
}

@Composable
private fun YouthPage(state: AppState, store: LocalStore, scale: Float, onCatalog: () -> Unit) {
    var taskText by remember { mutableStateOf("") }
    var classSubject by remember { mutableStateOf("") }
    var classTime by remember { mutableStateOf("08:00") }
    var classDay by remember { mutableStateOf("Lunes") }
    var chooseDay by remember { mutableStateOf(false) }
    val weekDays = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
    var running by remember { mutableStateOf(false) }
    var seconds by remember { mutableStateOf(15 * 60) }
    LaunchedEffect(running) {
        while (running && seconds > 0) { delay(1000); seconds-- }
        if (seconds == 0) running = false
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Text("Mi semana", fontSize = (26 * scale).sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp))
        Text("Organiza clases, tareas y compras. Todo queda guardado localmente.", color = Muted, fontSize = (13 * scale).sp)
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 15.dp)) {
            Column(Modifier.padding(17.dp)) {
                Text("🗓️ Mi horario", fontWeight = FontWeight.Bold, fontSize = (19 * scale).sp)
                Text("Anota las clases de cada día.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                ChoiceButton(classDay, Modifier.fillMaxWidth()) { chooseDay = true }
                OutlinedTextField(classSubject, { classSubject = it.take(50) }, label = { Text("Materia o actividad") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 5.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                    OutlinedTextField(classTime, { value -> if (value.length <= 5 && value.all { it.isDigit() || it == ':' }) classTime = value }, label = { Text("Hora, ej. 08:00") }, singleLine = true, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val subject = classSubject.trim()
                        val validTime = Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(classTime)
                        if (subject.isNotEmpty() && validTime) {
                            store.update { it.copy(schedule = it.schedule + ClassSession("c_${System.currentTimeMillis()}", classDay, classTime, subject)) }
                            classSubject = ""
                        }
                    }, enabled = classSubject.isNotBlank() && Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(classTime)) { Text("Añadir") }
                }
                val orderedSchedule = state.schedule.sortedWith(compareBy<ClassSession>({ weekDays.indexOf(it.day) }, { it.time }))
                if (orderedSchedule.isEmpty()) EmptyMessage("Tu horario aparecerá aquí.")
                weekDays.forEach { day ->
                    val entries = orderedSchedule.filter { it.day == day }
                    if (entries.isNotEmpty()) {
                        Text(day, color = Green, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                        entries.forEach { entry ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text(entry.time, fontWeight = FontWeight.Bold, color = Green, fontSize = 13.sp)
                                Text(entry.subject, Modifier.weight(1f).padding(horizontal = 10.dp), fontSize = 14.sp)
                                TextButton(onClick = { store.update { s -> s.copy(schedule = s.schedule.filterNot { it.id == entry.id }) } }) { Text("Quitar") }
                            }
                        }
                    }
                }
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 15.dp)) {
            Column(Modifier.padding(17.dp)) {
                Text("🎒 Mis tareas", fontWeight = FontWeight.Bold, fontSize = (19 * scale).sp)
                Text("Anota una cosa a la vez y márcala cuando termines.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
                    OutlinedTextField(value = taskText, onValueChange = { if (it.length <= 80) taskText = it }, label = { Text("Nueva tarea") }, singleLine = true, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(7.dp))
                    Button(onClick = { val text = taskText.trim(); if (text.isNotEmpty()) { store.update { it.copy(tasks = it.tasks + StudyTask("t_${System.currentTimeMillis()}", text, false)) }; taskText = "" } }) { Text("Añadir") }
                }
                if (state.tasks.isEmpty()) EmptyMessage("Tus tareas aparecerán aquí.")
                state.tasks.forEach { task ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Checkbox(checked = task.done, onCheckedChange = { checked -> store.update { s -> s.copy(tasks = s.tasks.map { if (it.id == task.id) it.copy(done = checked) else it }) } })
                        Text(task.text, Modifier.weight(1f), color = if (task.done) Muted else Ink)
                        TextButton(onClick = { store.update { s -> s.copy(tasks = s.tasks.filterNot { it.id == task.id }) } }) { Text("Quitar") }
                    }
                }
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 13.dp)) {
            Column(Modifier.padding(17.dp)) {
                Text("🧠 Tiempo de concentración", fontWeight = FontWeight.Bold, fontSize = (18 * scale).sp)
                Text("${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Green, modifier = Modifier.padding(vertical = 8.dp))
                Text("Mantén la app abierta para que el temporizador continúe.", color = Muted, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 10.dp)) {
                    Button(onClick = { running = !running }) { Text(if (running) "Pausar" else "Empezar 15 min") }
                    OutlinedButton(onClick = { running = false; seconds = 15 * 60 }) { Text("Reiniciar") }
                }
            }
        }
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(top = 13.dp, bottom = 18.dp)) {
            Column(Modifier.padding(17.dp)) { Text("🧺 Ayuda en casa", fontWeight = FontWeight.Bold); Text("Añade a la lista lo que hace falta.", color = Muted, modifier = Modifier.padding(vertical = 5.dp)); Button(onClick = onCatalog) { Text("Abrir catálogo") } }
        }
    }
    if (chooseDay) ChoiceDialog("Elige el día", weekDays.map { it to it }, { chooseDay = false }) { classDay = it; chooseDay = false }
}

@Composable
private fun EasyPage(state: AppState, scale: Float, onCatalog: () -> Unit, onList: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Text("Vista sencilla", fontSize = (27 * scale).sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp))
        Text("Accesos claros y letra grande.", color = Muted, fontSize = (14 * scale).sp)
        Card(shape = RoundedCornerShape(20.dp), colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Color(0xFFFFF4D9)), modifier = Modifier.fillMaxWidth().padding(top = 15.dp)) {
            Text("Revisa el mercado y la fecha del reporte antes de salir.", modifier = Modifier.padding(16.dp), color = Color(0xFF6D5423), fontSize = (14 * scale).sp)
        }
        BigActionCard("🧺", "Mi lista de compra", "${state.shopping.size} productos guardados", scale, onList)
        BigActionCard("🛒", "Precios por mercado", "Consulta los reportes disponibles", scale, onCatalog)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BigActionCard(icon: String, title: String, detail: String, scale: Float, onClick: () -> Unit) {
    Card(onClick = onClick, shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Color(0xFFE6ECE8)), modifier = Modifier.fillMaxWidth().padding(top = 13.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 31.sp); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, fontSize = (17 * scale).sp); Text(detail, color = Muted, fontSize = (12 * scale).sp) }; Text("›", color = Green, fontSize = 26.sp)
        }
    }
}

@Composable
private fun ShoppingPage(state: AppState, store: LocalStore, scale: Float, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            Text("‹", color = Green, fontSize = 28.sp, modifier = Modifier.clickable { onBack() }.padding(end = 9.dp))
            Text("Mi lista de compra", fontSize = (24 * scale).sp, fontWeight = FontWeight.ExtraBold)
        }
        Text("Guardada en este teléfono.", color = Muted)
        if (state.shopping.isEmpty()) EmptyMessage("La lista está vacía. Añade alimentos desde el catálogo.")
        state.shopping.forEachIndexed { index, id ->
            val food = foods.find { it.id == id } ?: return@forEachIndexed
            Card(shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(food.emoji, fontSize = 24.sp); Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(food.name, fontWeight = FontWeight.Bold, fontSize = (15 * scale).sp); Text("por ${food.unit}", color = Muted, fontSize = 11.sp) }
                    TextButton(onClick = { store.update { s -> s.copy(shopping = s.shopping.filterIndexed { i, _ -> i != index }) } }) { Text("Quitar") }
                }
            }
        }
    }
}

@Composable
private fun ShoppingRows(state: AppState, store: LocalStore, scale: Float, compact: Boolean) {
    if (state.shopping.isEmpty()) { EmptyMessage("Tu lista está vacía. Añade alimentos desde el catálogo."); return }
    state.shopping.take(if (compact) 4 else state.shopping.size).forEachIndexed { i, id ->
        val food = foods.find { it.id == id } ?: return@forEachIndexed
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(food.emoji, fontSize = 20.sp); Text(food.name, Modifier.weight(1f).padding(start = 9.dp), fontSize = (14 * scale).sp); TextButton(onClick = { store.update { s -> s.copy(shopping = s.shopping.filterIndexed { index, _ -> index != i }) } }) { Text("Quitar") }
        }
    }
}

@Composable
private fun EmptyMessage(text: String) {
    Surface(color = Color(0xFFFBFCFB), shape = RoundedCornerShape(15.dp), border = BorderStroke(1.dp, Color(0xFFD9E3DC)), modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Text(text, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(17.dp))
    }
}

@Composable
private fun ChoiceButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.padding(top = 5.dp)) { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
}

@Composable
private fun ChoiceDialog(title: String, options: List<Pair<String, String>>, onDismiss: () -> Unit, onSelect: (String) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = {
        if (options.isEmpty()) Text("Todavía no hay opciones guardadas.") else Column(Modifier.verticalScroll(rememberScrollState())) { options.forEach { (id, label) -> TextButton(onClick = { onSelect(id) }, modifier = Modifier.fillMaxWidth()) { Text(label, modifier = Modifier.fillMaxWidth()) } } }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } })
}

@Composable
private fun MarketDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Añadir mercado") }, text = {
        Column {
            OutlinedTextField(name, { name = it.take(50) }, label = { Text("Nombre del mercado") }, singleLine = true)
            OutlinedTextField(area, { area = it.take(50) }, label = { Text("Municipio o zona (opcional)") }, singleLine = true, modifier = Modifier.padding(top = 8.dp))
        }
    }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(name.trim(), area.trim()) }, enabled = name.isNotBlank()) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun PriceDialog(food: Food, market: Market, onDismiss: () -> Unit, onSave: (Double, String) -> Unit) {
    var price by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Reportar precio") }, text = {
        Column {
            Text("${food.name} · ${food.unit}\n${market.name}", color = Muted, fontSize = 13.sp)
            OutlinedTextField(price, { price = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.') }, label = { Text("Precio en CUP") }, singleLine = true, modifier = Modifier.padding(top = 8.dp))
            Text("Fecha del reporte: $today", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            if (error.isNotBlank()) Text(error, color = Color(0xFFB3261E), fontSize = 12.sp)
            Text("Se guarda localmente en este teléfono; no es un dato oficial.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }, confirmButton = { TextButton(onClick = { val value = price.toDoubleOrNull(); if (value == null || value <= 0) error = "Escribe un precio mayor que cero." else onSave(value, today) }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

private fun formatCup(value: Double): String {
    val formatter = java.text.NumberFormat.getNumberInstance(Locale("es", "CU"))
    formatter.maximumFractionDigits = 2
    return "${formatter.format(value)} CUP"
}
